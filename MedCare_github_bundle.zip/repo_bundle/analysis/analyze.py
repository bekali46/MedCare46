#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MedCare — анализ влияния городской среды на сон и вариабельность сердца (ВСР).
Строит Рисунок 1 (4 панели) и печатает ключевую статистику.

Запуск:
    pip install -r requirements.txt
    python analysis/analyze.py            # данные берутся из data/sleep_data.csv
    python analysis/analyze.py path.csv   # или укажи свой файл
Результат: figures/figure1.png и figures/figure1.pdf
"""
import sys, os
import numpy as np
import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from scipy import stats
import textwrap as _tw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "data", "sleep_data.csv")
OUTDIR = os.path.join(ROOT, "figures")
os.makedirs(OUTDIR, exist_ok=True)

# ---------- чтение данных (разделитель ;) ----------
raw = []
with open(DATA, encoding="utf-8") as f:
    f.readline()  # заголовок
    for line in f:
        line = line.strip()
        if not line:
            continue
        p = line.split(";")
        if len(p) < 14:
            continue
        try:
            raw.append(dict(sub=p[0], age=int(p[1]), sex=p[2], date=p[3], typ=p[4],
                            noise=float(p[5]), light=float(p[6]), pm=float(p[7]),
                            pulse=float(p[8]), hrv=float(p[9]), deep=float(p[10]),
                            total=float(p[11]), awk=float(p[12]), feel=float(p[13])))
        except ValueError:
            continue

# берём только участников с полным набором из 12 ночей
from collections import Counter
cnt = Counter(r["sub"] for r in raw)
rows = [r for r in raw if cnt[r["sub"]] == 12]
N = len(rows)
noise = np.array([r["noise"] for r in rows]); light = np.array([r["light"] for r in rows])
pm = np.array([r["pm"] for r in rows]);       pulse = np.array([r["pulse"] for r in rows])
hrv = np.array([r["hrv"] for r in rows]);      deep = np.array([r["deep"] for r in rows])
awk = np.array([r["awk"] for r in rows])
subs = sorted(set(r["sub"] for r in rows))
print("Ночей в анализе:", N, "| участников:", len(subs))

# ---------- B: шум vs ВСР ----------
r_b, p_b = stats.pearsonr(noise, hrv)
print("Шум ~ ВСР: r=%.3f p=%.2e" % (r_b, p_b))

# ---------- C: парное сравнение тихие vs шумные ----------
def paired(metric):
    q, nz = [], []
    for s in subs:
        qv = [rr[metric] for rr in rows if rr["sub"] == s and rr["typ"] == "тихая"]
        nv = [rr[metric] for rr in rows if rr["sub"] == s and rr["typ"] == "шумная"]
        q.append(np.mean(qv)); nz.append(np.mean(nv))
    q = np.array(q); nz = np.array(nz)
    t, pp = stats.ttest_rel(nz, q)
    return q, nz, pp
hq, hn, hp = paired("hrv"); dq, dn, dp = paired("deep"); aq, an, ap = paired("awk")
hrv_pct = (hn.mean() - hq.mean()) / hq.mean() * 100
deep_min = dn.mean() - dq.mean()
print("ВСР тихие=%.1f шумные=%.1f (%.1f%%) p=%.4f" % (hq.mean(), hn.mean(), hrv_pct, hp))
print("Глубокий сон тихие=%.1f шумные=%.1f (%+.1f мин) p=%.4f" % (dq.mean(), dn.mean(), deep_min, dp))

# ---------- D: матрица корреляций ----------
envs = [("Шум, дБ", noise), ("Свет, лк", light), ("PM2.5", pm)]
outs = [("ВСР", hrv), ("Глуб. сон", deep), ("Пробужд.", awk), ("Пульс", pulse)]
cmat = np.zeros((len(envs), len(outs))); pmat = np.zeros_like(cmat)
for i, (_, ev) in enumerate(envs):
    for j, (_, ov) in enumerate(outs):
        cmat[i, j], pmat[i, j] = stats.pearsonr(ev, ov)

# ---------- A: один участник по ночам ----------
PA = subs[2] if len(subs) > 2 else subs[0]
pr = sorted([rr for rr in rows if rr["sub"] == PA], key=lambda r: int(r["date"][:2]))
a_x = np.arange(1, len(pr) + 1); a_hrv = np.array([r["hrv"] for r in pr]); a_typ = [r["typ"] for r in pr]

# =================== РИСУНОК ===================
mpl.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.linewidth": 0.8,
    "xtick.major.width": 0.8, "ytick.major.width": 0.8, "xtick.major.size": 3, "ytick.major.size": 3,
    "axes.labelsize": 9.5, "axes.titlesize": 10, "figure.dpi": 300})
TEAL = "#0D9488"; CORAL = "#D95D39"; GREY = "#555555"
def dsp(ax): ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
ps = "p < 0,001" if p_b < 0.001 else "p = %.3f" % p_b

fig = plt.figure(figsize=(14.6, 8.2))
gs = GridSpec(2, 2, figure=fig, hspace=0.5, wspace=0.22, left=0.05, right=0.985, top=0.95, bottom=0.235)
def pl(ax, s): ax.text(-0.09, 1.1, s, transform=ax.transAxes, fontsize=13, fontweight="bold", va="top")

# A
axA = fig.add_subplot(gs[0, 0]); dsp(axA)
for k in range(len(a_x)):
    axA.scatter(a_x[k], a_hrv[k], s=48, color=CORAL if a_typ[k] == "шумная" else TEAL, zorder=3)
axA.plot(a_x, a_hrv, color="#AAB4BC", lw=1, zorder=1)
mi = int(np.argmin(a_hrv))
axA.annotate("резкий ночной шум", xy=(a_x[mi], a_hrv[mi]), xytext=(a_x[mi] + 0.5, a_hrv[mi] + 7),
             fontsize=7.6, ha="left", arrowprops=dict(arrowstyle="-", lw=0.7, color=GREY))
axA.scatter([], [], color=TEAL, s=48, label="тихая ночь"); axA.scatter([], [], color=CORAL, s=48, label="шумная ночь")
axA.legend(frameon=False, fontsize=7.8, loc="upper right")
axA.set_xticks(a_x); axA.set_xlabel("Ночь наблюдения (участник %s)" % PA); axA.set_ylabel("ВСР, RMSSD (мс)")
axA.set_title("ВСР по ночам у одного участника", loc="left"); pl(axA, "A")

# B
axB = fig.add_subplot(gs[0, 1]); dsp(axB)
cols = [CORAL if r["typ"] == "шумная" else TEAL for r in rows]
axB.scatter(noise, hrv, s=16, c=cols, alpha=0.55, edgecolor="none")
sl, ic, _, _, _ = stats.linregress(noise, hrv); xx = np.linspace(noise.min(), noise.max(), 100); yy = ic + sl * xx
n = len(noise); xm = noise.mean(); ssx = np.sum((noise - xm) ** 2); resid = hrv - (ic + sl * noise)
se = np.sqrt(np.sum(resid ** 2) / (n - 2)); ci = stats.t.ppf(0.975, n - 2) * se * np.sqrt(1 / n + (xx - xm) ** 2 / ssx)
axB.fill_between(xx, yy - ci, yy + ci, color=GREY, alpha=0.15, lw=0); axB.plot(xx, yy, color="black", lw=1.3)
axB.axvline(40, color=GREY, ls=(0, (4, 3)), lw=0.8); axB.text(40.5, hrv.max() - 1, "норма ВОЗ\n(40 дБ)", fontsize=7, color=GREY, va="top")
axB.text(0.97, 0.95, "r = %.2f\n%s\nn = %d ночей" % (r_b, ps, N), transform=axB.transAxes, ha="right", va="top",
         fontsize=8.5, bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="0.7", lw=0.6))
axB.set_xlabel("Шум в спальне ночью, L$_{night}$ (дБ)"); axB.set_ylabel("ВСР, RMSSD (мс)")
axB.set_title("Ночной шум и вариабельность сердца", loc="left"); pl(axB, "B")

# C
sub = GridSpecFromSubplotSpec(1, 3, subplot_spec=gs[1, 0], wspace=0.8)
def star(p): return "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else "н.з."
data = [("ВСР, RMSSD (мс)", hq, hn, hp), ("Глубокий сон (мин)", dq, dn, dp), ("Пробуждения (шт.)", aq, an, ap)]
cax = []
for j, (name, q, nz, p) in enumerate(data):
    ax = fig.add_subplot(sub[0, j]); dsp(ax); cax.append(ax)
    mq, mn = q.mean(), nz.mean(); sq = q.std(ddof=1) / np.sqrt(len(q)); sn = nz.std(ddof=1) / np.sqrt(len(nz))
    ax.bar([0], [mq], 0.62, color=TEAL, label="тихие"); ax.bar([1], [mn], 0.62, color=CORAL, label="шумные")
    ax.errorbar([0], [mq], yerr=[sq], fmt="none", ecolor="black", elinewidth=0.9, capsize=3)
    ax.errorbar([1], [mn], yerr=[sn], fmt="none", ecolor="black", elinewidth=0.9, capsize=3)
    top = max(mq + sq, mn + sn); ax.plot([0, 0, 1, 1], [top * 1.04, top * 1.08, top * 1.08, top * 1.04], color="black", lw=0.8)
    ax.text(0.5, top * 1.10, star(p), ha="center", va="bottom", fontsize=9)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["тихие", "шумные"], fontsize=8); ax.set_ylim(0, top * 1.25)
    ax.set_ylabel(name, fontsize=8.5)
    if j == 0:
        ax.legend(frameon=False, fontsize=7.5, loc="upper left", ncol=2, bbox_to_anchor=(-0.02, 1.14), columnspacing=1)
_rt = cax[1].get_position().y1; _cx = cax[1].get_position().x0 + cax[1].get_position().width / 2
fig.text(_cx, _rt + 0.072, "Тихие/тёмные vs шумные/светлые ночи  (n = %d участников, парный t-критерий)" % len(subs),
         ha="center", va="bottom", fontsize=9.5)
fig.text(cax[0].get_position().x0 - 0.042, _rt + 0.08, "C", fontsize=13, fontweight="bold", va="bottom")

# D
axD = fig.add_subplot(gs[1, 1]); axD.axis("off")
axD.text(-0.09, 1.1, "D", transform=axD.transAxes, fontsize=13, fontweight="bold", va="top")
axD.set_title("Корреляции: среда ↔ организм (r)", loc="left", y=1.02)
colL = [o[0] for o in outs]; rowL = [e[0] for e in envs]; cell = []
for i in range(len(envs)):
    rr = []
    for j in range(len(outs)):
        st = "***" if pmat[i, j] < 0.001 else "**" if pmat[i, j] < 0.01 else "*" if pmat[i, j] < 0.05 else ""
        rr.append("%.2f%s" % (cmat[i, j], st))
    cell.append(rr)
tbl = axD.table(cellText=cell, rowLabels=rowL, colLabels=colL, loc="center", cellLoc="center", colWidths=[0.2] * len(outs))
tbl.auto_set_font_size(False); tbl.set_fontsize(9.5); tbl.scale(1, 1.9)
for (ri, ci), c in tbl.get_celld().items():
    c.set_edgecolor("#E2E8F0")
    if ri == 0 or ci == -1: c.set_text_props(fontweight="bold")
    if ri > 0 and ci >= 0:
        c.set_facecolor("#FCEAE3" if cmat[ri - 1, ci] < 0 else "#E6F3F1")
axD.text(0.5, -0.14, "* p<0,05   ** p<0,01   *** p<0,001.  Отрицательная связь — розовый, положительная — бирюза.",
         transform=axD.transAxes, ha="center", fontsize=7.4, color="0.4")

cap = (f"Рисунок 1. Собственные данные проекта: {len(subs)} участников, по 12 ночей каждый (n = {N} ночей). "
       "(A) ВСР (RMSSD) по ночам у одного участника; тихие ночи — бирюзовые, шумные — коралловые. "
       "(B) Связь ночного шума (L$_{night}$) и ВСР; линия — регрессия, заливка — 95% ДИ, пунктир — норма ВОЗ "
       f"(r = {r_b:.2f}; {ps}; n = {N}). "
       f"(C) Внутрисубъектное сравнение тихих и шумных ночей (n = {len(subs)}; парный t-критерий; среднее ± SEM): "
       f"ВСР {hq.mean():.0f}→{hn.mean():.0f} мс ({hrv_pct:.0f}%), глубокий сон {dq.mean():.0f}→{dn.mean():.0f} мин. "
       "(D) Матрица корреляций факторов среды с показателями организма.")
fig.add_artist(plt.Line2D([0.05, 0.985], [0.205, 0.205], color="0.8", lw=0.8, transform=fig.transFigure))
fig.text(0.05, 0.188, "\n".join(_tw.wrap(cap, width=232, break_long_words=False)), ha="left", va="top",
         fontsize=8.3, color="0.12", linespacing=1.5)

fig.savefig(os.path.join(OUTDIR, "figure1.png"), dpi=300, bbox_inches="tight", facecolor="white")
fig.savefig(os.path.join(OUTDIR, "figure1.pdf"), bbox_inches="tight", facecolor="white")
print("Готово. Рисунок сохранён в figures/figure1.png и figure1.pdf")
